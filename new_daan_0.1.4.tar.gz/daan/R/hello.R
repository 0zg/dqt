# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Build and Reload Package:  'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'
##############
# oso 20180917 bedrijsnamen via google_maps verrijken met domeinnamen
# oso 20190909 v08 google geeft nu json terug als resultaat, omgezet om  de data uit die json te halen

# General-purpose data wrangling
#library(tidyverse)
library(dplyr)
library(stringr)
# For crawling AND scraping
library(Rcrawler)
#library(xml2)
#library(rvest)
# for export to csv
#library(rio)
library(jsonlite)
library(utils)
library(readr)

hello <- function() {
  print("Hoi ik ben daan, zie een lijst met wat ik kan doen door daan:: in te tikken")
}

verrijk_bedrijf_met_url <- function(bedrijfsnaam=c('everything4office in almere')) {
  ##BEGIN Parameters setten
  #param_SearchInput <- c(
  #  "Techn.Ontwerpbur./Instrumentenmakerij Jonkman in URETERP"
  #  ,'jansen in hoorn'
  #  )
  #getwd()
  #param_SearchInput <- c("everything4office in almere") #as.character(read.csv("teZoekenBedrijfsnamen.csv",header=F)$V1)
  param_SearchInput <- bedrijfsnaam #as.character(read.csv("teZoekenBedrijfsnamen.csv",header=F)$V1)

  ##END parameters setten

  df_output <- base::list()

  for(i in 1:length(param_SearchInput) ) {
    #hieronder alleen logica, niks aanpassen
    str_baseSearchQuery = "https://www.google.nl/maps/search/"
    #str_baseSearchQuery = "http://www.google.nl/search?q="
    #postfix = "&hl=nl&npsic=0&rflfq=1&rlha=0&tbm=lcl&sa=X&biw=640&bih=480"
    postfix = ""
    str_addedSearchQuery <- gsub(' ', '+', URLencode(param_SearchInput[i]) ) #url friendly text

    lst_Search_businesses = c( paste(str_baseSearchQuery,str_addedSearchQuery,postfix,sep='') )
    lst_Search_businesses[1]
    # binnen de maps zoek pagina links door de lijst zoeken naar naam en website

    # custom dir, om projectmap schoon te houden
    a_WorkDir <- print(paste(getwd(),"/scraper_htmls/", sep=""))
    dir.create(file.path(a_WorkDir), showWarnings = FALSE)
    customCrawlerDir <- a_WorkDir

    tmp_rnd <- as.character( floor(runif(1,10000,99999)) )
    tmp_rndfile <- paste(customCrawlerDir,"tmpfile_func_",tmp_rnd,".html", sep="")
    download.file(lst_Search_businesses[1], destfile = tmp_rndfile , cacheOK = FALSE, method="auto")#werkt niet op linux: method="wininet")
    Sys.sleep(runif(1,0.5,1))#wachten op download
    #tmp_html <- read_html(tmp_rndfile, encoding = "UTF-8")#bestand inlezen, hoeft niet meer

    #alleen javascript deel van bestand inlezen. de data zit in de literal javascript data type (json achtig)
    #rits aan tijdelijke tabellen maken hieronder: tt is temptext, js is json object
    str_rndfile <- readr::read_file(tmp_rndfile)
    tt2 <- Rcrawler::ContentScraper(HTmlText =  str_rndfile, astext = FALSE, encod="UTF-8"
                                    ,XpathPatterns = c("//script")
                                    ,PatternsName = c("jscript")
                                    ,ManyPerPattern = TRUE)

    tt3 <- tt2$jscript[8] #in de toekomst indezxen vervangen met namen, om rigide te maken
    #tt3
    tt4 <- strsplit(tt3,";")
    tt5 <- tt4[[1]][2]
    tt6 <- strsplit(tt5,"=")
    #tt7
    tt7 <- tt6[[1]][2]
    #json_data
    json_data <- jsonlite::fromJSON(tt7)#,unexpected.escape="skip")
    tt8 <- json_data[[4]][[3]]
    tt9 <- substr(tt8,6,stringr::str_length(tt8))
    js1 <- jsonlite::fromJSON(tt9)#,unexpected.escape="skip") # einde van uitpluizen data uit html, en result in json object stoppen

    #node en [[1]][[2]][[2]][[15]] = de eerste bedrijfsinformatie node
    #het volgende bedrijf is [[1]][[2]][[3]][[15]]
    #de dollarteken dient opgehoogt te worden [[1]][[2]][[$$]][[15]]

    js1_gezochtingoogle <- paste(js1[[1]][[1]], collapse = " ") #zoekstring wat in google is ingetikt/plakt
    jsCnt <- length(js1[[1]][[2]]) #haal aantal bedrijven in resultaat op, node waar alle bedrijven in de lijst zitten
    jsCntFix <- 2 #als je een lijst aan bedrijven hebt, staat het eerste bedrijf in de 2e node (1e node is zoekinformatie)
    df_sub_output <- list()
    if(jsCnt == 1 ) {jsCntFix <- 1} #als een exacte bedrijf gevonden is krijg je geen lijst, dit zorgt ervoor dat de info toch opgehaald wordt

    for(ii in jsCntFix:jsCnt) {
      tryCatch({ #trycatch om door te scrapen in de bedrijvenlijst, ook als bepaalde info niet gevonden kan worden (door advertentie, of lege cellen)
        # write your intended code here
        js2 <- js1[[1]][[2]][[ii]][[15]] #bedrijfsinformatie tabel
        js2[[12]] #bedrijf_naam
        js2[[14]] #bedrijf_type
        js2[[8]][[2]] #bedrijf_site

        js2[[4]] #bedrijf_vest_tel
        js2[[3]][[1]] #bedrijf_vest_straat_hsnr
        js2[[3]][[2]] #bedrijf_vest_postcode_plaats
        js2[[5]][[9]] #bedrijf_vest_review_aantal
        js2[[5]][[8]] #bedrijf_vest_review_score

        df_js3 <- data.frame("gezochtInGoogle" = c( js1_gezochtingoogle )
                             , "result_naam_vest_inGoogle" = c( paste(js2[[12]], collapse = " ")  )
                             , "result_type_vest_inGoogle" = c( paste(js2[[14]], collapse = " ") )
                             , "result_site_vest_inGoogle" = c( paste(js2[[8]][[2]], collapse = " ")  )
        )

        df_sub_output[[ii]] <- df_js3 #toevoegen aan sub-lijst met resultaten van pagina
      }, warning = function(w) {
        # log the warning or take other action here
      }, error = function(e) {
        # log the error or take other action here
      }, finally = {
        # this will execute no matter what else happened
      })
    }


    #tonen data
    #View(bind_rows(df_sub_output))
    df_output[[i]] <- dplyr::bind_rows(df_sub_output) # toevoegen aan hoofd-lijst met resultaten van andere zoekacties


    Sys.sleep(1)#1 seconde wachten tot volgende google-search (om niet gebanned te worden)
  }

  #
  #
  #alle resultaten concatenreren (union_all) en tonen
  #View(bind_rows(df_output))
  df_output <- dplyr::bind_rows(df_output)
  df_output <- dplyr::filter(df_output, stringr::str_length(result_site_vest_inGoogle) > 0 ) #filter regels zonder url
  df_output <- dplyr::distinct(df_output) #duplicaat regels verwijderen
  #lijst URL's te gebruiken door de ScraperV01.R code

  return(df_output)
}

#verrijk_bedrijf_met_url()
